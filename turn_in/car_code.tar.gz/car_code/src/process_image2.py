import numpy as np
import matplotlib.pyplot as plt


class Run(object):

  def __init__(self,i,j1,j2):
    self.j1=j1
    self.j2=j2
    self.i=i
    self.blob = None

class Blob(object):

  def __init__(self,i1,j1,i2,j2):
    self.i1=i1
    self.j1=j1
    self.i2=i2
    self.j2=j2

  def __init__(self,run):
    self.i1=run.i
    self.j1=run.j1
    self.i2=run.i
    self.j2=run.j2
  

def threshold(X, threshold):
  X = np.where(X >= threshold, X, 0)
  X_mask = X[:,:,0] * X[:, :, 1] * X[:, :, 2]
  X_mask = np.asarray([X_mask, X_mask, X_mask]).transpose(1,2,0)
  X = X * X_mask
  X = np.around(X)
  return X

def formRuns(X,skip=1):

  runs = {}

  for i in range(len(X)):

    start = 0
    inRun = False
    for j in range(0,len(X[i]),skip):
      if not inRun and X[i][j] == 0.0: continue
      if not inRun and X[i][j] == 1.0: start = j; inRun = True
      if inRun and X[i][j] == 0.0: 
        if not i in runs.keys():
          runs[i] = []
        runs[i].append(Run(i,start,j))
        inRun = False
 
  return runs

def overlap(run1,run2):

  if run1.j1 <= run2.j2 and run1.j1 >= run2.j1: return True
  if run1.j2 <= run2.j2 and run1.j2 >= run2.j1: return True
  return False

def createBlob(run,blobs):
    blob = Blob(run)
    run.blob = blob
    blobs.append(blob)

def drawBlob(blob,X):

  for i in range(blob.i1,blob.i2):
    for j in range(blob.j1,blob.j2):
      X[i][j] = 10

def formBlobs(X,skip=1):

  X = threshold(X,0.95)
  X = np.sum(X,axis=2) / 3.0
 
  runs = formRuns(X,skip=1)
  blobs = []

  start = 0

  for i in range(0,224,skip): 
    if i in runs.keys(): break
    start += 1

  if start == 224:
    return X,224/2,25,224-25

  for run in runs[start]:
    createBlob(run,blobs)

  for i in range(start + skip,112,skip): # process top half of image

    if i not in runs.keys(): continue

    for run1 in runs[i]:
      foundBlob = False
      if i - skip not in runs.keys():
        createBlob(run1,blobs)
        continue
      for run2 in runs[i-skip]:
        if overlap(run1,run2):
          foundBlob = True
          if run1.blob is not None:
            run1.blob.j2 = max(run2.j2,run1.j2)
            run2.blob = run1.blob
          else:
            run1.blob = run2.blob
            run1.blob.i2 = run1.i
            run1.blob.j1 = min(run1.blob.j1,run1.j1)
            run1.blob.j2 = max(run1.blob.j2,run1.j2)

      if not foundBlob:
        createBlob(run1,blobs)
  best = None
  curr_ratio = 0.0
  for blob in blobs:
    bottom = blob.j2 - blob.j1 if blob.j2 - blob.j1 > 3 else 224
    if blob.i1 > 0: bottom = 224
    ratio =  (blob.i2 - blob.i1) / float(bottom)
    if ratio > curr_ratio:
      curr_ratio = ratio
      best = blob
  lb,ub = 0,224

#  for blob in blobs:
#    drawBlob(blob,X)
  mid = 224 / 2
  if best is not None:
    lb,ub = max(0,best.j1 - 10),min(best.j2 + 10,len(X))
    if blob.j1 > 100 and blob.j2 < 150:
      print blob.i1,blob.i2,blob.j1,blob.j2
    mid = (ub + lb ) * 0.5

  return X,mid,lb,ub
