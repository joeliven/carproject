#!/usr/bin/env python

import rospy
from std_msgs.msg import Bool
from race.msg import drive_param
from race.msg import pid_input
from race.msg import classify
from collections import deque
import time

kp = 14.0
kd = 0.09
servo_offset = 18.5
prev_error = 0.0 
vel_input = 25.0
buffer_length = 5

pub = rospy.Publisher('drive_parameters', drive_param, queue_size=1)

class Controller(object):
	'''
	Controller class.
	Determines car commands using Lidar with PID control and a vision-based classifier.
	'''
	def __init__(self):
		self.shouldTurn = False # classifier decision
		self.y_intercept = None
		self.x_light = 138 # expected position if we're in middle of track
		self.prev_y = 105 # track previous y-intercept if vision returns None
		self.history = []
		rospy.Subscriber("error", pid_input, self.control)
		rospy.Subscriber("classifier_decision", classify, self.updateClassifierDecision)
		rospy.spin()

	def updateClassifierDecision(self,data):
	    '''
	    Update classifier decisions
	    '''
	    self.shouldTurn = data.decision
	    self.y_intercept = data.y_intercept
	    self.x_light = data.x_light #y_intercept = data.y_intercept
	    self.prev_y = self.y_intercept if self.y_intercept is not None else self.prev_y

	def control(self,data):
		'''
		Determines car angle and velocity for driving
		'''
		global prev_error
		global vel_input
		global kp
		global kd

		## Your code goes here
		# 1. Scale the error
		# 2. Apply the PID equation on error
		# 3. Make sure the error is within bounds
		angle = data.pid_error*kp;
		if angle > 100:
			angle = 100
		if angle < -100:
			angle = -100
    

	        # do extra processing with the classifier decision

		if (self.shouldTurn == False):

		  useY = True
		  useX = False # experimental
		  if useX: # if True we try to follow the overhead light. Currently in progress...x_light is accurate but control needs work.

			angle = max(-20.0,angle)
			angle = min(20.0,angle)
			x_offset = (self.x_light - 140) / 22.0
			l_mult = 2.0
			r_mult = 6.0
			mult = 3.0
			if x_offset < 0:
			  x_bump = min(r_mult,x_offset * r_mult)
			else:
			  x_bump = max(x_offset * l_mult,-l_mult)
			angle += x_bump
		  if useY: # adjust position based off of red carpet to side of corridor.
		    angle = max(-20.0,angle)
		    angle = min(18.0,angle)

		    if self.y_intercept is not None:
			  if self.y_intercept < 100:#224/2:
			    angle = min(22.5,angle) + 2#1.5
			  else:
			    angle = min(12.5,angle)
		    else: # use previous intercept if classifier did not return a value.
			  if self.prev_y < 100:#224/2:
			    angle = min(22.5,angle) + 2#1.5
			  else:
			    angle = min(12.5,angle)
		msg = drive_param();
		if(data.pid_vel == 0):
			msg.velocity = -8
		else:
			msg.velocity = vel_input	
		msg.angle = angle
		pub.publish(msg)

if __name__ == '__main__':
	global kp
	global kd
	global vel_input
	print("Listening to error for PID")
	kp = 300.0 #input("Enter Kp Value: ") # 300
	kd = 1.0#0.09 #input("Enter Kd Value: ") # 1
	vel_input = 7.6 # 10.0 #input("Enter Velocity: ")
	rospy.init_node('pid_controller', anonymous=True)
	try:
		Controller()
	except rospy.ROSInterruptException:
		pass
