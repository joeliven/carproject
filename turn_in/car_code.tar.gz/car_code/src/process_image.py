import numpy as np
import matplotlib.pyplot as plt


class Run(object):

  def __init__(self,i1,i2):
    self.i1=i1
    self.i2=i2


class Blob(object):

  def __init__(self,i1,j1,i2,j2):
    self.i1=i1
    self.j1=j1
    self.i2=i2
    self.j2=j2

def threshold(X, threshold):
  X = np.where(X >= threshold, X, 0)
  X_mask = X[:,:,0] * X[:, :, 1] * X[:, :, 2]
  X_mask = np.asarray([X_mask, X_mask, X_mask]).transpose(1,2,0)
  X = X * X_mask
  X = np.around(X)
  return X

def scan(X):

  X = threshold(X,0.95)
  X = np.sum(X,axis=2) / 3.0
#  X = X[:,0:22]
  
  width = 10; length = 50;
  run = []
  for i in range(0,len(X), width / 2):
    run.append(np.sum(X[0:length,i:(i+width/2)]) / (width * length))
  print run
  seenLight = False
  x = 0
  i=0
  thresh = 0.05
  max_ = 0.0
  while i < len(run): 
    if run[i] > thresh: 
      ct = 0
      sum_ = 0.0
      while i < len(run) and run[i] > thresh: ct+=1; sum_ += run[i]; i+=1
      if ct <= 3:  
        if sum_ > max_: max_ = sum_; x=i; print i
    else: i+= 1
  print 'percent',float(x) / len(run)
  x = int(float(x)/len(run) * len(X)) # + width * 0.5
  print max_,x
    #seenLight = True; x = i*width + width * 0.5
    #if run[i] <= 0.0: 
    #  if not seenLight: continue
    #  else: break
#  plt.imshow(X)  
#  plt.show()
  lb,ub =  max(0,x - 20), min(len(X),x + 20)
  print 'x=',x
  if x == 0: lb,ub = 50, 224-50
  if x >= len(X): lb,ub = 50, 224-50
  print lb,ub
  return X,int(lb),int(ub)

  
