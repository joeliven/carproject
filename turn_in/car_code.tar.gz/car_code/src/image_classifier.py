#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from std_msgs.msg import Bool
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from image_utils import preprocess_image
from classifier import _Classifier
from race.msg import classify

pub = rospy.Publisher('classifier_decision', classify, queue_size=1)

class Classifier(object):
  '''
  Classifies the image as straight or turn.
  This class works with a variety of classifier approaches.
  '''
  def __init__(self):

      self.bridge = CvBridge()
      self.encoding = 'rgb8'

      self.lastImage = None
      self.num = 0
      RESTORE_PATH = "/home/ubuntu/JJG_workspace/src/race/models/vgg6t_a_checkpoint-57"
      META_PATH = "/home/ubuntu/JJG_workspace/src/race/models/vgg6t_a_checkpoint-57.meta"
      print("Loading model")
      self._classifier = _Classifier(meta_path=META_PATH, weights_path=RESTORE_PATH)
      print("Model loaded")
      rospy.Subscriber("rgb/image_rect",Image,self.classify)
      rospy.spin()
    

  def classify(self,data):
      # Load image from message
      image = self.convertImg(data)
      
      # preprocess to turn rgb into bgr and smaller image
      image = preprocess_image(image,dbg=False)
 
      # call classifier
      shouldTurn, y_intercept, mid, duration = self._classifier.predict(image, verbose=True)

      # publish decision for control
      msg = classify()
      msg.decision = shouldTurn
      msg.y_intercept = y_intercept
      msg.x_light = mid#y_intercept = y_intercept
      print (mid) #pub.publish(msg)#shouldTurn)
      pub.publish(msg)#shouldTurn)

  def convertImg(self,data):
      try:
        cv_image = self.bridge.imgmsg_to_cv2(data, self.encoding)
      except CvBridgeError as e:
        print(e)

      (rows,cols,channels) = cv_image.shape
      return np.asarray(cv_image)

if __name__ == '__main__':
    print("Classifying turn decision")
    rospy.init_node('image_classifier', anonymous=True)
    try:
      Classifier()
    except rospy.ROSInterruptException:
      pass

