This code contains two directories:
msg/ Includes our custom classify message used for classifier to control communication
src/ Source code for controlling the car and classifying images
